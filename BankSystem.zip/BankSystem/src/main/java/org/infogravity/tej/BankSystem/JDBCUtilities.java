package org.infogravity.tej.BankSystem;

import java.sql.Connection;




import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;

public class JDBCUtilities {
	
		
		 // JDBC driver name and database URL
	public static DataSource geOracleDataSource()
	{
		 // JDBC driver name and database URL
	

		String JDBC_DRIVER ="org.h2.Driver";
		//String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver"; 
		//String DB_URL="jdbc:oracle:thin:@localhost:1521/SID";
		String DB_URL="jdbc:h2:~/test";

		 BasicDataSource bdSource = new BasicDataSource();
		 bdSource.setDriverClassName(JDBC_DRIVER);
         bdSource.setUrl(DB_URL);
         bdSource.setUsername("HR");
         bdSource.setPassword("HR");
         //bdSource.setInitialSize(5);//
         //bdSource.setMaxActive(10);
		
		return bdSource;
	}
	
	
	public static Connection getOracleDatabaseConnection() throws SQLException{
		Connection conn=null;
		conn=geOracleDataSource().getConnection();
		
		return conn;
	}
	
}
