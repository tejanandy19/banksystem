package org.infogravity.tej.BankSystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import oracle.net.aso.r;

//Databse Queries
public class DAO {

	// class level to avoid repeatation
	Connection conn = null;
	PreparedStatement stm = null;

	// get details of account number
	public Customer get_CustomerDetails(int accnumber) {

		Customer customer = new Customer();

		try {
			conn = JDBCUtilities.getOracleDatabaseConnection();
			conn.setAutoCommit(false);
			stm = conn.prepareStatement("SELECT * FROM CUSTOMER" + " WHERE Customer_AccNumber= ?");
			stm.setInt(1, accnumber);

			ResultSet result = stm.executeQuery();

			// retrieving the data
			while (result.next()) {
				customer.setCustomer_AccNumber(result.getInt("Customer_AccNumber"));
				customer.setCustomer_Name(result.getString("CUSTOMER_NAME"));
				customer.setCustomer_Address(result.getString("Customer_Address"));
				customer.setAccount_Balance(result.getInt("Account_Balance"));

			}
			conn.commit();

			//to test in console
			// System.out.println(customer.toString());
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			try {
				if (conn != null)
					conn.close();
				if (stm != null)
					stm.close();
			} catch (Exception e) {

			}
		}

		// returnng customer details
		return customer;
	}

	// this method is used for withdraw amount
	public String withdraw(int deducted, int accnumber) {

		Customer customer1 = get_CustomerDetails(accnumber);
		// previous balance to display
		int previous_Balance = customer1.getAccount_Balance();

		int test = 0;

		String sql = "UPDATE CUSTOMER set Account_Balance=? " + " WHERE " + " Customer_AccNumber= ?;";

		try {
			conn = JDBCUtilities.getOracleDatabaseConnection();
			conn.setAutoCommit(false);
			stm = conn.prepareStatement(sql);
			// calculation
			int balance = (previous_Balance - deducted);
			stm.setInt(1, balance);
			stm.setInt(2, accnumber);
			test = stm.executeUpdate();

			conn.commit();

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}
		// to close connections
		finally {
			try {
				if (conn != null)
					conn.close();
				if (stm != null)
					stm.close();
			} catch (Exception e) {

			}
		}

		// pulling updated data from db
		Customer customer = get_CustomerDetails(accnumber);

		// after operations sending data
		return "Amount withdraw in account:" + customer.getCustomer_AccNumber() + "\nprevious Account Balance:"
				+ previous_Balance + "\nAmount Withdrawal:" + deducted + "\nAccount Balance:"
				+ customer.getAccount_Balance();

	}

	// this method is used for debit
	public String debit(int credit, int accnumber) {

		Customer customer1 = get_CustomerDetails(accnumber);
		int previous_Balance = customer1.getAccount_Balance();
		int test = 0;

		String sql = "UPDATE CUSTOMER set Account_Balance=? " + " WHERE " + " Customer_AccNumber= ?;";
		System.out.println(accnumber);
		try {
			conn = JDBCUtilities.getOracleDatabaseConnection();
			// conn.setAutoCommit(false);
			stm = conn.prepareStatement(sql);

			int balance = (previous_Balance + credit);
			stm.setInt(1, balance);
			stm.setInt(2, accnumber);

			test = stm.executeUpdate();
			conn.commit();

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}
		// to close connections
		finally {
			try {
				if (conn != null)
					conn.close();
				if (stm != null)
					stm.close();
			} catch (Exception e) {

			}
		}

		// pulling updated data from db

		Customer customer = get_CustomerDetails(accnumber);

		// int index = get_Location(accnumber);
		// Customer customer = bank_Customer.get(index);
		/*
		 * double previous_balance=customer.getAccount_Balance() ;
		 * 
		 * double update_acc=customer.getAccount_Balance()- deducted;
		 * customer.setAccount_Balance(update_acc);
		 */

		return "Amount credited in account:" + customer.getCustomer_AccNumber() + "\nprevious Account Balance:"
				+ previous_Balance + "\nAmount credited:" + credit + "\ncurrent Account Balance:"
				+ customer.getAccount_Balance();

	}

}
