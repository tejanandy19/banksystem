package org.infogravity.tej.BankSystem;

import java.util.Date;

public class Transaction {

	private int account_Number;
	private int amount;
	private String type;
	public int getAccount_Number() {
		return account_Number;
	}
	public void setAccount_Number(int account_Number) {
		this.account_Number = account_Number;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "Transaction [account_Number=" + account_Number + ", amount=" + amount + ", type=" + type + "]";
	}
	
	
	
}
