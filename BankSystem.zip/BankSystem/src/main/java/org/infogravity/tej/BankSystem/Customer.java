package org.infogravity.tej.BankSystem;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Customer {

	private int customer_AccNumber;
	private String CUSTOMER_NAME;
	private String customer_Address;
	private int Account_Balance;

	/*
	 * private Account customer_account;
	 * 
	 * public Account getCustomer_account() { return customer_account; }
	 * 
	 * public void setCustomer_account(Account customer_account) {
	 * this.customer_account = customer_account; }
	 */
	public int getCustomer_AccNumber() {
		return customer_AccNumber;
	}

	public void setCustomer_AccNumber(int customer_AccNumber) {
		this.customer_AccNumber = customer_AccNumber;
	}

	public String getCustomer_Name() {
		return CUSTOMER_NAME;
	}

	public void setCustomer_Name(String customer_Name) {
		this.CUSTOMER_NAME = customer_Name;
	}

	public String getCustomer_Address() {
		return customer_Address;
	}

	public void setCustomer_Address(String customer_Address) {
		this.customer_Address = customer_Address;
	}

	public int getAccount_Balance() {
		return Account_Balance;
	}

	public void setAccount_Balance(int account_Balance) {
		Account_Balance = account_Balance;
	}
	
	

	@Override
	public String toString() {
		return "Customer [customer_AccNumber=" + customer_AccNumber + ", customer_Name=" + CUSTOMER_NAME
				+ ", customer_Address=" + customer_Address + ", Account_Balance=" + Account_Balance + "]";
	}

	
}
